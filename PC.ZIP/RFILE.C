#include "rsc.h"

/*
*****************************************************************************
												LEER
*****************************************************************************
Proposito:	Leer un archivo del formato especificado y desplegarlo en
				pantalla.
Autor:		Ariel Guerrero / Luis Jara

Formato de archivo:
	|---------------|---------------|---------------|---------------|
	|   CABECERA	 |  REGISTRO_1   |	  ...			|	REGISTRO_N   |
	|---------------|---------------|---------------|---------------|
	|<---3 bytes--->|<---3 bytes--->|<---3 bytes--->|<---3 bytes--->|

	CABECERA
		|	 |->	PERIMETRO:	Los dos primeros bytes indican la distancia
		|							recorrida por la unidad exploradora.
		|----->	NUML:			El tercer byte indica el numero de lados
									de la habitacion explorada.
	REGISTRO_N
		|	 |->	MAGNITUD:	Longitud del trayecto.
		|----->	RUMBO:		Indica hacia donde se dirigia la unidad movil.

Datos arqueologicos:

	Fecha				Version			Comentario
	-----				-------			----------
	9/AGO/00			1              Implementacion del algoritmo


*****************************************************************************
*/
void rfile(void)
{
	struct dato {
		unsigned short int byte2;
		unsigned char byte1;

	}cabecera, registro;

	int cnt=0;


	FILE	*in_file;	//dato que se descarga a la pc
	FILE	*out_file;	//En formato texto

	in_file = fopen(FILE_IN, "rb");
	if(in_file == NULL){
		exit(8);
	};
	out_file = fopen(FILE_OUT, "wt");
	if(out_file == NULL){
		exit(8);
	};


	fread((char *)&cabecera,1,sizeof(cabecera),in_file);

	printf("\nPerimetro\t\t:%hd",cabecera.byte2);
	fprintf(out_file,"\nPerimetro\t\t:%hd",cabecera.byte2);
	printf("\nNumero de lados\t\t:%hd",cabecera.byte1);
	fprintf(out_file,"\nPerimetro\t\t:%hd",cabecera.byte1);

	printf("\n\nMAGNITUD\t\tDIRECCION");
	fprintf(out_file,"\nMAGNITUD\t\tDIRECCION");

	cnt = cabecera.byte1;

	while(cnt){
		cnt--;
		fread((char*)&registro,1, sizeof(registro), in_file);
		printf("\n%d\t\t\t%c",registro.byte2, registro.byte1);
		fprintf(out_file,"\n%d\t\t\t%c",registro.byte2, registro.byte1);

	};

	fclose(in_file);
	fclose(out_file);

}