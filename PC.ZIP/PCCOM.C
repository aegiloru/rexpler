#include "rsc.h"

void main(void)
{
	textmode(C80);
	clrscr();
	titulo();
	comi();	//Descargar los datos de la unidad rexpler
	gotoxy(1,7);
	rfile();		//Interpretar los datos
	clrscr();

}

void titulo(void)
{

	textcolor(RED);
	gotoxy(19,1);
	cprintf("UNIVERSIDAD CATOLICA NUESTRA SE�ORA DE LA ASUNCION");
	gotoxy(30,2);
	cprintf("MICROPROCESADORES I");
	gotoxy(25,3);
	cprintf("------------------------------");
	gotoxy(36,4);
	cprintf("REXPLER");
	textcolor(RED);
	gotoxy(25,5);
	cprintf("Robot EXPLorador de pERimetros");
	gotoxy(25,6);
	cprintf("------------------------------");

	textcolor(BLUE);
	gotoxy(29,25);
	cprintf("L E D  �JARA/GUERRERO");

	textcolor(WHITE);

}

void tecla_msg(void)
{

	textcolor(LIGHTBLUE|BLINK);
	gotoxy(23,23);
	delline();
	cprintf("Presione una tecla para continuar");
	getch();
	gotoxy(23,23);
	delline();
	textcolor(WHITE);
}