#include "rsc.h"
/*
****************************************************************************
						Recursos para programacion del Puerto serial
****************************************************************************
Autor:			Ariel Guerrero
Fecha:	      8/junio/2000
Proposito:		Driver del puerto serial, utiliza programacion directa del
					serial usando acceso a los servicios del BIOS(14h).
****************************************************************************
*/

/*
---------------------------------------------------------------------------
									config_port()
									-------------
Proposito:			Configurar puerto serial
Entrada:				Parametros de configuracion
Salida:				-
---------------------------------------------------------------------------

Entrada:		AH <- 0h				Configurar el puerto serie
				DX <- port			Numero de puerto serie
				AL <- parametros	Parametros de configuracion

						Bits	!	 Significado
						------!----------------
						7-5	!		Velocidad(baudios)
						4-3	!		Paridad
						2		!		Numero de bits de parada (STOP BITS)
						1-0	!		Longitud de caracter
*/
void config_port(int port,int velocidad,int paridad, int sbit, int dbit)
{
	unsigned char parametros;
	parametros = velocidad + paridad + sbit + dbit;
	asm {                // inicializamos el puerto
			mov ah,0h      // el servicio 0h nos permite inicializar el puerto
			mov dx,port  // pasamos el puerto a 'dx'
			mov al,parametros  // pasamos la suma de los par�metros a 'al'
			int 14h        // solicitamos la interrupci�n 14h
	}
}
/*
---------------------------------------------------------------------------
									estado()
									-----------
Proposito:			Leer palabra de estado del puerto de comunicaciones
Entrada:				Numero de Puerto
Salida:				Estado de la linea de comunicaciones
---------------------------------------------------------------------------
Entrada:		AH	<- 3h				Servicio del BIOS de Estado
				DX <- port			Numero de puerto serie
Salidas:		AX	  					Palabra de Estado
				AL 					Estado del Modem (No usado)

				AH						Estado de la linea de comunicaciones
						Bit	!	 Significado
						------!----------------
						  7	!  Tiempo excedido
						  6	!  TSR vacio
						  5	!  THR vacio
						  4	!  Interrupcion (break)
						  3	!  Error de formato (framing)
						  2	!  Error de paridad
						  1	!  Error de sobrescritura (overrun)
						  0	!  Dato Preparado
*/
unsigned char estado(int port)
{
	unsigned char states;
	asm {
		mov ah,3h   // Utiliza el servicio 3h del BIOS
		mov dx,port
		int 14h
		mov states,ah
	}
	return states;
}
/*
---------------------------------------------------------------------------
									leer()
									------
Proposito:	Leer caracter de la linea. Activa la se�al DTR y
				no mirara is  ha recibido un caracter hasta que no reciba
				la se�al correcta del DSR.

Entrada:		AH <- 2h		Servicio del BIOS A solicitar
				DX <- port	Numero de puerto a leer

Salida:     AL 	Caracter leido
				AH    Estado de la linea (No usado)
---------------------------------------------------------------------------
*/
void leer_puerto( int port, unsigned char *dato_rx)
{
	unsigned char dato;
	asm {             // recoge un car�cter
		mov ah,2h
		mov dx,port
		int 14h
		mov dato,al
	}
	*dato_rx = dato;
}

/*
---------------------------------------------------------------------------
									escribir_puerto()
									-----------------
Proposito:	Activa las se�ales DTR y RTS del modem y no transmite hasta
				que no reciba las se�ales correctas para DSR y TSR,
				El caracter se enviara a la UART cuando este vacio el TSR.

Entrada:		AH <- 1h		Servicio del BIOS A solicitar
				DX <- port	Numero de puerto a leer
				AL 	Caracter a enviar

Salida:		AH    Estado de la linea (No usado)
---------------------------------------------------------------------------
*/
void escribir_puerto(unsigned char dato_tx, int port)
{
	asm {               // envia un car�cter
		mov ah,1h
		mov dx,port
		mov al, dato_tx
		int 14h
	}
}

/*
*****************************************************************************
										COMI
*****************************************************************************
Proposito:	Implementa un protocolo de parada y espera para comunicacion
				serial con la unidad exploradora

Autor:		Ariel Guerrero / Luis Jara


Datos arqueologicos:

	Fecha				Version			Comentario
	-----				-------			----------
	1/AGO/00			1              Implementacion del algoritmo


*****************************************************************************
*/

void comi(void)
{
unsigned char data_tx;
unsigned char data_rx;
unsigned char buffer=0;
int end_rx = 1;	// Recepcion de datos habilitado
int pasada = 0;	 // Numero de veces que se repite el caracter de control

FILE	*out_file;

// Inicializar el puerto serial
	config_port(COM1, BD9600, NINGUNA, STOPb_1, DATAb_8);

	// Archivo buffer para la recepcion de datos
	out_file = fopen(FILE1,"w+b");
	if (out_file == NULL)
	{
		exit(8);
	};


	data_tx = DTR;						//Listo para el BD1
	escribir_puerto(data_tx, COM1);

	while( end_rx )
	{
	if(estado(COM1)&1)
		{
			leer_puerto(COM1, &data_rx);
			if (data_rx == ETX)
			{
				pasada++;
				if(pasada == 1) buffer = data_rx;
				if(pasada == 2)
				{
					fprintf(out_file,"%c",data_rx);
					buffer=0;
//					printf("%c", data_rx);
					pasada=0;
				};
			}
			else
			{
					fprintf(out_file,"%c",data_rx);
			};
		}
		else
		{
			if ((pasada == 1)&&(buffer == ETX))
			{
				end_rx = 0;
				fclose(out_file);
			}
		}
	}
}

/*
*****************************************************************************
												rfile
*****************************************************************************
Proposito:	Leer un archivo del formato especificado y desplegarlo en
				pantalla.
Autor:		Ariel Guerrero / Luis Jara

Formato de archivo:
	|---------------|---------------|---------------|---------------|
	|   CABECERA	 |  REGISTRO_1   |	  ...			|	REGISTRO_N   |
	|---------------|---------------|---------------|---------------|
	|<---3 bytes--->|<---3 bytes--->|<---3 bytes--->|<---3 bytes--->|

	CABECERA
		|	 |->	PERIMETRO:	Los dos primeros bytes indican la distancia
		|							recorrida por la unidad exploradora.
		|----->	NUML:			El tercer byte indica el numero de lados
									de la habitacion explorada.
	REGISTRO_N
		|	 |->	MAGNITUD:	Longitud del trayecto.
		|----->	RUMBO:		Indica hacia donde se dirigia la unidad movil.

Datos arqueologicos:

	Fecha				Version			Comentario
	-----				-------			----------
	9/AGO/00			1              Implementacion del algoritmo


*****************************************************************************
*/
void rfile(void)
{
	struct dato {
		unsigned char byte2a;
		unsigned char byte2b;
		unsigned char byte1;

	}cabecera, registro;

	unsigned short int byte2;

	int cnt=0;

	int linea= 10;

	FILE	*in_file;	//dato que se descarga a la pc
	FILE	*out_file;	//En formato texto

	in_file = fopen(FILE_IN, "rb");
	if(in_file == NULL){
		exit(8);
	};
	out_file = fopen(FILE_OUT, "wt");
	if(out_file == NULL){
		exit(8);
	};


	fread(&cabecera,1,sizeof(cabecera),in_file);
	byte2 = (unsigned short int)cabecera.byte2a * 10000 +(unsigned short int)cabecera.byte2b;
//	printf("\nPerimetro\t\t:%hd%hd",cabecera.byte2a,cabecera.byte2b);
//	fprintf(out_file,"\nPerimetro\t\t:%hd",cabecera.byte2b);

	printf("\n\tPerimetro:\t\t%hd\n\tUnidad:\t\tcentimetro",byte2);

	printf("\n\tNumero de lados:\t\t%hd",cabecera.byte1);
	fprintf(out_file,"\n\tPerimetro\t\t:%hd",cabecera.byte1);

	printf("\n\n\tMAGNITUD\t\tDIRECCION");
	fprintf(out_file,"\n\tMAGNITUD\t\tDIRECCION");

	cnt = cabecera.byte1;

	while(cnt){
		if(linea == 22)
		{
			tecla_msg();
			clrscr();
			titulo();
			linea = 7;
			gotoxy(1,7);
		};
		linea++;
		cnt--;
		fread(&registro,1, sizeof(registro), in_file);
		byte2 = (unsigned short int)registro.byte2a * 10000 +(unsigned short int)registro.byte2b;
		printf("\n\t%hd\t\t\t%c",byte2, registro.byte1);
		fprintf(out_file,"\n\t\t%d\t\t\t%c",byte2, registro.byte1);

	};

	fclose(in_file);
	fclose(out_file);
	tecla_msg();

}