#include "rsc.h"

void comi(void)
{
unsigned char data_tx;
unsigned char data_rx;
unsigned char buffer=0;
int end_rx = 1;	// Recepcion de datos habilitado
int pasada = 0;	 // Numero de veces que se repite el caracter de control

FILE	*out_file;


// Inicializar el puerto serial
	config_port(COM1, BD9600, NINGUNA, STOPb_1, DATAb_8);

	// Archivo buffer para la recepcion de datos
	out_file = fopen(FILE1,"w+b");
	if (out_file == NULL)
	{
		exit(8);
	};


	data_tx = DTR;						//Listo para el BD1
	escribir_puerto(data_tx, COM1);

	while( end_rx )
	{
	if(estado(COM1)&1)
		{
			leer_puerto(COM1, &data_rx);
			if (data_rx == ETX)
			{
				pasada++;
				if(pasada == 1) buffer = data_rx;
				if(pasada == 2)
				{
					fprintf(out_file,"%c",data_rx);
					buffer=0;
					printf("%c", data_rx);
					pasada=0;
				};
			}
			else
			{
				if(data_rx==SP)
				{
					data_rx=0;
					fprintf(out_file,"%c",data_rx);
					printf("%c",data_rx);
				}
				else
				{
					fprintf(out_file,"%c",data_rx);
					printf("%c",data_rx);
				};
			};
		}
		else
		{
			if ((pasada == 1)&&(buffer == ETX))
			{
				end_rx = 0;
				fclose(out_file);
			}
		}
	}
}


